import React from 'react';
import DealsTab from './DealsTab';

const Deals = () => {
  return (
    <div className='deals-header' style={{margin: '20px 0px 0px 70px'}}>
      <DealsTab />
    </div>
  );
}

export default Deals;